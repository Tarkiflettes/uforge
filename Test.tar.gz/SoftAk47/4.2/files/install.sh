unzip master.sh
cd Tarkinder-server-master
npm install
