cd Tarkinder-server-master
nohup npm start & 
