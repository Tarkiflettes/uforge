cd /root/
git clone https://github.com/Tarkiflettes/Tarkinder-server.git Tarkinder-server
cd Tarkinder-server
npm install
nohup npm start &
