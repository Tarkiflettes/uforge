cd /root/
wget https://github.com/Tarkiflettes/Tarkinder-server/archive/master.zip
unzip master.zip
cd Tarkinder-server-master
npm install
nohup npm start &
