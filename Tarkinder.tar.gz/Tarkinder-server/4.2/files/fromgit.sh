curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -
sudo apt-get install -y nodejs

cd /root/
wget https://github.com/Tarkiflettes/Tarkinder-server/archive/master.zip
unzip master.zip
cd Tarkinder-server-master
npm install
nohup npm start &
