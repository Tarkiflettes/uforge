curl -sL https://deb.nodesource.com/setup_8.x | sudo -E bash -
sudo apt-get install -y nodejs

cd /uploads/mysoftware/Tarkinder-server
unzip master.zip
cd Tarkinder-server-master
npm install
