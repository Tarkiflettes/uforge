cd /uploads/mysoftware/SoftAk47
unzip master.zip
cd Tarkinder-server-master
npm install
