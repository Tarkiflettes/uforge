cd /uploads/mysoftware/Tarkinder-server
unzip master.zip
cd Tarkinder-server-master
npm install
