cd /uploads/mysoftware/SoftAk47/Tarkinder-server-master
nohup npm start & 
