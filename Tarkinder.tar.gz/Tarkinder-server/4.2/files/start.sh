cd /uploads/mysoftware/Tarkinder-server/Tarkinder-server-master
nohup npm start & 
